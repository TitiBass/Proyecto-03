//
//  ViewController.swift
//  fbdemo
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase
class ViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var username: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        if sesion == 1{
            self.performSegue(withIdentifier: "toLoginAccountVC", sender: nil )
        }
    }

    @IBAction func adduser(_ sender: UIButton) {
     
        guard let correo = email.text,
            let pass = username.text else { return }
        
        Auth.auth().signIn(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            } else {
                self.performSegue(withIdentifier: "toLoginAccountVC", sender: nil )
            }
        }
        
        /* Firestore.firestore().collection("users").addDocument(data: ["username":username.text,"email": email.text,"timestamp": FieldValue.serverTimestamp()]){(error)in
            if let error = error {
                print(error)
                return
            }
        }*/
    }
}

