//
//  secondViewController.swift
//  fbdemo
//
//  Created by Usuario invitado on 11/23/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
var sesion = Int()
class secondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

Firestore.firestore().collection("users").addDocument(data: ["username":username.text,"email": email.text,"timestamp": FieldValue.serverTimestamp()]){(error)in
            if let error = error {
                print(error)
                sesion = 1
                return sesion
    }}}


}
